#!/bin/bash
xdg-open "$(dirname "$0")/index.html" 2>/dev/null || sensible-browser "$(dirname "$0")/index.html"
